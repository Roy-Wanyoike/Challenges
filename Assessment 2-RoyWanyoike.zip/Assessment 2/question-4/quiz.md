# Create a simple todo App that is:
- Able to create a task with a title, description and Date (expected completion date) 
- Able to Show all created todos.
- Able Delete one todo. 
- Able Delete All todos. 