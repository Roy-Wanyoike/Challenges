PALINDROME –A palindrome is a word, number, phrase, or other sequence of characters which reads the same backward as forward.
Write a program that checks whether a word is a palindrome or not.
Examples of a palindromes
(race car)
